

Sairaj Loke
210001035

q1
implemented the + - * / ops for infix to postfix exp. conversion

please check the terminal images for both questions


q2
Bin2Dec (assume no signed bit)
1. normal type (eg. 010) of unlim size

note: u can ignore the cpp tests , mytests, gtests.
i was just experimenting with the gtests module

*/


Some references:

nagendra sir's slides
https://pontus.digipen.edu/~mmead/www/Courses/CS220/IEEE754.html
https://www.javatpoint.com/semantic-error
https://www.sciencedirect.com/topics/engineering/syntax-error#:~:text=Syntax%20errors%20are%20mistakes%20in%20the%20source%20code%2C%20such%20as,be%20generated%20by%20the%20compiler.
 https://stackoverflow.com/questions/12371417/why-does-python-ironpython-report-illegal-characters-in-path-when-the-word-b
https://www.geeksforgeeks.org/lexical-error/
https://www.geeksforgeeks.org/what-is-error-recovery/
