#include<iostream>
#include<stack>
#include<set>
#include <fstream>

using namespace std;



int f(string input_str){
    int ptr = 0;
    while(ptr < input_str.size() && input_str[ptr] == ' ') ptr++;

    if(ptr + 1 >= input_str.size() || (input_str[ptr] != '/')){
        cout<<"not a comment\n"; return 0;
    }

    if(input_str[ptr + 1] == '/'){
        cout<<"comment\n"; return 0;
    }else if(input_str[ptr + 1] != '*'){
        cout<<"not a comment\n"; return 0;
    }else{
        ptr += 2;
    }
    
    bool endOfComment = false;
    while(ptr < input_str.size() - 1 && !endOfComment){
        if(input_str[ptr] == '*' && input_str[ptr + 1] == '/'){
            if(ptr + 1 == input_str.size() - 1){
                cout<<"comment\n"; return 0;
            }else{
                endOfComment = true; ptr++;
            }
        }
        ptr++;
    }
    

    while(ptr < input_str.size() && input_str[ptr] == ' ') ptr++;
    if(ptr == input_str.size() && endOfComment){
        cout<<"a comment\n"; 
    }else{
        cout<<"not a comment\n"; 
    }

    return 0;
}

int main() {
    string inputstr;
    ifstream ftest("comment_tests.txt");
    std::getline(ftest, inputstr) ; 
    while(std::getline(ftest, inputstr)){
        std::cout<<inputstr<<" : ";

        f(inputstr);
    }
    ftest.close() ; 

    return 0;
}
