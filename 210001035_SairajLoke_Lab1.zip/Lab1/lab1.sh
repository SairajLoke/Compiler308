
#!/bin/bash

echo "hey"
# g++ check_keywords.cpp -o check_keywords
# .\check_keywords.exe

# g++ check_vowel.cpp -o check_vowel
# .\check_vowel.exe

# g++ check_comment.cpp -o check_comment
# .\check_comment.exe