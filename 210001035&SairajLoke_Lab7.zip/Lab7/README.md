Sairaj Loke
210001035 Assignment 7 2April 1

Note: these notes can also be found in individual files

Q1 Bin2Dec (assume no signed bit)
1. normal type (eg. 010) of unlim size
2. neg num? not yet
note: u can ignore the cpp tests , mytests, gtests.
i was just experimenting with the gtests module

-------------------------------------------------------------------------
Q2
Sairaj Loke 
210001035
considering emails such that:

1st start alphanumeric ............................................(must)
second letter could be . _ - or any other alphanumeric char .......(optional)
@..................................................................(must)
post @ , atleast 1 letter..........................................(must)
atleast 1 alphanumeric post . .....................................(must)
2 chars before compulsary . and 

reference - https://docs.blackberry.com/en/id-comm-collab/blackberry-athoc/blackberry-athoc/7_9/create-publish-alerts/email-format-validation/valid-email-address-examples


-------------------------------------------------------------------------
Q3
Sairaj Loke 
210001035

allowing empty space (not newline ) before digit
also note the newline necc otherwise 99 gives is a digit and error as well

------------------------------------------------------------------------
Q4
Sairaj Loke
210001035


as equal a's and b's on both sides