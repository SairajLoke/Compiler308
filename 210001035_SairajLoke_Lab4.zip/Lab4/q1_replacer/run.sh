lex replacer.l 
cc  lex.yy.c  -ll  -o rep.out
./rep.out


