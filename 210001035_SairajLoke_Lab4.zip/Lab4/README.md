
SAIRAJ LOKE

My reference for regex

https://westes.github.io/flex/manual/Patterns.html

all necessary photos and codes have been provided for each folder
to run, just run the run.sh file in each folder