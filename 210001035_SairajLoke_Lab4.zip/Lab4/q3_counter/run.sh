lex cntr.l 
cc  lex.yy.c  -ll  -o cntr.out
./cntr.out


