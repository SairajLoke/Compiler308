lex printscan.l 
cc  lex.yy.c  -ll  -o ps.out
./ps.out


