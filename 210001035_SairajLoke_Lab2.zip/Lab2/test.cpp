#include<iostream>
using namespace std;

int main(){

    cout<<int('b')<<endl;
}