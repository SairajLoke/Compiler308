#include<stdio.h>
/*
this code prints Aao Sai
*/
int main(){
    printf("Aao Sai");
    //to print
}